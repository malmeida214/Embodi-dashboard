// EMBODI Dashboard — QuickBooks Live Data API
// Vercel Serverless Function

const https = require('https');

const CLIENT_ID     = process.env.QB_CLIENT_ID;
const CLIENT_SECRET = process.env.QB_CLIENT_SECRET;
const REFRESH_TOKEN = process.env.QB_REFRESH_TOKEN;
const REALM_ID      = process.env.QB_REALM_ID;
const BASE_URL      = 'quickbooks.api.intuit.com';

// ── 1. REFRESH ACCESS TOKEN ──────────────────────────────────────────────────
async function getAccessToken() {
  return new Promise((resolve, reject) => {
    const credentials = Buffer.from(`${CLIENT_ID}:${CLIENT_SECRET}`).toString('base64');
    const body = `grant_type=refresh_token&refresh_token=${encodeURIComponent(REFRESH_TOKEN)}`;

    const options = {
      hostname: 'oauth.platform.intuit.com',
      path: '/oauth2/v1/tokens/bearer',
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(body),
      },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          if (parsed.access_token) resolve(parsed.access_token);
          else reject(new Error(`Token refresh failed: ${data}`));
        } catch (e) { reject(e); }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// ── 2. FETCH QB REPORT ───────────────────────────────────────────────────────
async function fetchReport(accessToken, reportName, params = '') {
  return new Promise((resolve, reject) => {
    const path = `/v3/company/${REALM_ID}/reports/${reportName}?minorversion=70${params}`;
    const options = {
      hostname: BASE_URL,
      path,
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Accept': 'application/json',
      },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(e); }
      });
    });
    req.on('error', reject);
    req.end();
  });
}

// ── 3. PARSE P&L REPORT ──────────────────────────────────────────────────────
function parsePL(report) {
  const rows = report?.Rows?.Row || [];
  let revenue = 0, expenses = 0, netIncome = 0;

  const getVal = (row) => {
    const cols = row?.ColData || [];
    const last = cols[cols.length - 1];
    return parseFloat(last?.value || '0') || 0;
  };

  rows.forEach(row => {
    const type = row.type;
    const header = row?.Header?.ColData?.[0]?.value || '';
    if (type === 'Section') {
      if (header.toLowerCase().includes('income') || header.toLowerCase().includes('revenue')) {
        (row?.Rows?.Row || []).forEach(r => {
          if (r.type === 'DataRow') revenue += getVal(r);
        });
        if (row?.Summary) revenue = getVal(row.Summary) || revenue;
      }
      if (header.toLowerCase().includes('expense')) {
        if (row?.Summary) expenses = getVal(row.Summary);
      }
    }
    if (type === 'DataRow' && header.toLowerCase().includes('net income')) {
      netIncome = getVal(row);
    }
  });

  // Try summary row for net income
  rows.forEach(row => {
    const header = row?.Header?.ColData?.[0]?.value || '';
    if (header.toLowerCase().includes('net income') || header.toLowerCase().includes('net earnings')) {
      if (row?.Summary) netIncome = getVal(row.Summary);
    }
  });

  return { revenue, expenses, netIncome: netIncome || revenue - expenses };
}

// ── 4. PARSE EXPENSE CATEGORIES ──────────────────────────────────────────────
function parseExpenseCategories(report) {
  const cats = {
    Rent: 0, Labor: 0, Marketing: 0,
    Processing: 0, 'Dues/Subs': 0, Other: 0,
  };

  const rentKeywords    = ['rent', 'lease'];
  const laborKeywords   = ['outside service', 'contractor', 'labor', 'payroll', 'wage', 'salary', 'kate'];
  const marketKeywords  = ['marketing', 'advertis', 'ads', 'google', 'meta', 'social'];
  const processKeywords = ['merchant', 'processing', 'stripe', 'square', 'payment fee'];
  const duesKeywords    = ['dues', 'subscription', 'software', 'license'];

  const classify = (name = '') => {
    const n = name.toLowerCase();
    if (rentKeywords.some(k => n.includes(k)))    return 'Rent';
    if (laborKeywords.some(k => n.includes(k)))   return 'Labor';
    if (marketKeywords.some(k => n.includes(k)))  return 'Marketing';
    if (processKeywords.some(k => n.includes(k))) return 'Processing';
    if (duesKeywords.some(k => n.includes(k)))    return 'Dues/Subs';
    return 'Other';
  };

  const walkRows = (rows = []) => {
    rows.forEach(row => {
      if (row.type === 'DataRow') {
        const name = row?.ColData?.[0]?.value || '';
        const val  = parseFloat(row?.ColData?.[row.ColData.length - 1]?.value || '0') || 0;
        const cat  = classify(name);
        cats[cat] += val;
      }
      if (row?.Rows?.Row) walkRows(row.Rows.Row);
    });
  };

  walkRows(report?.Rows?.Row || []);
  return cats;
}

// ── 5. PARSE MONTHLY P&L ─────────────────────────────────────────────────────
function parseMonthlyPL(report) {
  const columns = report?.Columns?.Column || [];
  const monthLabels = columns
    .filter(c => c.ColType === 'Money')
    .map(c => c.ColTitle || '');

  const monthly = monthLabels.map(label => ({ month: label, revenue: 0, expenses: 0, net: 0 }));

  const walkRows = (rows = []) => {
    rows.forEach(row => {
      const header = row?.Header?.ColData?.[0]?.value || '';
      const isIncome  = header.toLowerCase().includes('income') || header.toLowerCase().includes('revenue');
      const isExpense = header.toLowerCase().includes('expense');

      if (row?.Summary?.ColData && (isIncome || isExpense)) {
        const vals = row.Summary.ColData.slice(1);
        vals.forEach((col, i) => {
          const v = parseFloat(col.value || '0') || 0;
          if (monthly[i]) {
            if (isIncome)  monthly[i].revenue  += v;
            if (isExpense) monthly[i].expenses += v;
          }
        });
      }
      if (row?.Rows?.Row) walkRows(row.Rows.Row);
    });
  };

  walkRows(report?.Rows?.Row || []);
  monthly.forEach(m => { m.net = m.revenue - m.expenses; });
  return monthly.filter(m => m.revenue > 0 || m.expenses > 0);
}

// ── 6. PARSE BALANCE SHEET ───────────────────────────────────────────────────
function parseBalanceSheet(report) {
  let currentAssets = 0, currentLiabilities = 0, cashBalance = 0;

  const getLastVal = (row) => {
    const cols = row?.ColData || [];
    return parseFloat(cols[cols.length - 1]?.value || '0') || 0;
  };

  const walkRows = (rows = [], context = '') => {
    rows.forEach(row => {
      const header = row?.Header?.ColData?.[0]?.value?.toLowerCase() || '';
      const name   = row?.ColData?.[0]?.value?.toLowerCase() || '';
      const ctx    = context + ' ' + header;

      if (ctx.includes('current asset') && row?.Summary) {
        currentAssets = getLastVal(row.Summary);
      }
      if (ctx.includes('current liabilit') && row?.Summary) {
        currentLiabilities = getLastVal(row.Summary);
      }
      if ((name.includes('checking') || name.includes('cash') || name.includes('bank')) && row.type === 'DataRow') {
        cashBalance += getLastVal(row);
      }
      if (row?.Rows?.Row) walkRows(row.Rows.Row, ctx);
    });
  };

  walkRows(report?.Rows?.Row || []);

  return {
    currentAssets,
    currentLiabilities,
    currentRatio: currentLiabilities > 0 ? +(currentAssets / currentLiabilities).toFixed(2) : null,
    cashBalance,
  };
}

// ── 7. MAIN HANDLER ──────────────────────────────────────────────────────────
export default async function handler(req, res) {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET');
  if (req.method === 'OPTIONS') return res.status(200).end();

  try {
    const accessToken = await getAccessToken();

    const currentYear = new Date().getFullYear();
    const lastYear    = currentYear - 1;

    // Fetch all reports in parallel
    const [
      plThisYear,
      plLastYear,
      plMonthly,
      balanceSheet,
      expenseDetail,
    ] = await Promise.all([
      fetchReport(accessToken, 'ProfitAndLoss',
        `&date_macro=This+Year&summarize_column_by=Total`),
      fetchReport(accessToken, 'ProfitAndLoss',
        `&start_date=${lastYear}-01-01&end_date=${lastYear}-12-31&summarize_column_by=Total`),
      fetchReport(accessToken, 'ProfitAndLoss',
        `&date_macro=This+Year&summarize_column_by=Month`),
      fetchReport(accessToken, 'BalanceSheet',
        `&date_macro=Today`),
      fetchReport(accessToken, 'ProfitAndLoss',
        `&date_macro=This+Year&summarize_column_by=Total`),
    ]);

    const thisYear  = parsePL(plThisYear);
    const prevYear  = parsePL(plLastYear);
    const monthly   = parseMonthlyPL(plMonthly);
    const balance   = parseBalanceSheet(balanceSheet);
    const expCats   = parseExpenseCategories(expenseDetail);

    const yoyRevGrowth = prevYear.revenue > 0
      ? +((thisYear.revenue - prevYear.revenue) / prevYear.revenue * 100).toFixed(1)
      : null;

    const mrr = monthly.length > 0
      ? Math.round(monthly.reduce((s, m) => s + m.revenue, 0) / monthly.length)
      : Math.round(thisYear.revenue / 12);

    const netMargin   = thisYear.revenue > 0
      ? +(thisYear.netIncome / thisYear.revenue * 100).toFixed(1) : 0;
    const ebitda      = thisYear.netIncome; // simplified (no D&A this year)
    const ebitdaMargin = netMargin;

    const processingRate = expCats.Processing > 0 && thisYear.revenue > 0
      ? +(expCats.Processing / thisYear.revenue * 100).toFixed(1) : null;
    const laborRate = expCats.Labor > 0 && thisYear.revenue > 0
      ? +(expCats.Labor / thisYear.revenue * 100).toFixed(1) : null;

    res.status(200).json({
      lastUpdated: new Date().toISOString(),
      currentYear,
      thisYear: {
        revenue:    Math.round(thisYear.revenue),
        expenses:   Math.round(thisYear.expenses),
        netIncome:  Math.round(thisYear.netIncome),
        netMargin,
        ebitda:     Math.round(ebitda),
        ebitdaMargin,
        mrr,
        arr:        mrr * 12,
      },
      prevYear: {
        revenue:   Math.round(prevYear.revenue),
        expenses:  Math.round(prevYear.expenses),
        netIncome: Math.round(prevYear.netIncome),
        netMargin: prevYear.revenue > 0
          ? +(prevYear.netIncome / prevYear.revenue * 100).toFixed(1) : 0,
      },
      yoyRevGrowth,
      monthly,
      expenseCategories: expCats,
      balance,
      kpis: {
        processingRate,
        laborRate,
        ltvCac:         19.7,
        blendedCac:     154,
        ltv:            3027,
        churnRate:      85,
        breakEven:      9921,
        activeMembers:  48,
        unconvLeads:    322,
        winBackPool:    168,
      },
    });

  } catch (err) {
    console.error('QB API Error:', err);
    res.status(500).json({
      error: 'Failed to fetch QuickBooks data',
      message: err.message,
      lastUpdated: new Date().toISOString(),
    });
  }
}
